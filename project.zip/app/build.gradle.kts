plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.companion"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.companion"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // API key GitHub Secret se aati hai, code mein nahi likhni
        val key = System.getenv("GEMINI_API_KEY") ?: ""
        buildConfigField("String", "API_KEY", "\"$key\"")
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
