package com.example.companion

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator
import java.util.Random
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class OrbView(ctx: Context) : View(ctx) {

    var fast = false

    private class P(val a: Float, val r: Float, val s: Float, val color: Int)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private val colors = intArrayOf(
        Color.parseColor("#5DCAA5"), Color.parseColor("#85B7EB"), Color.parseColor("#EF9F27")
    )
    private val pts: List<P> = Random(7).let { rnd ->
        List(90) {
            P(rnd.nextFloat() * 360f, 0.2f + rnd.nextFloat() * 0.8f,
                0.4f + rnd.nextFloat() * 1.2f, colors[rnd.nextInt(3)])
        }
    }

    private val ticker = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase += if (fast) 3f else 0.8f
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ticker.start()
    }

    override fun onDetachedFromWindow() {
        ticker.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val big = min(width, height) / 2f * 0.92f

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        paint.color = Color.parseColor("#1D9E75"); paint.alpha = 110
        canvas.drawCircle(cx, cy, big, paint)
        paint.color = Color.parseColor("#378ADD"); paint.alpha = 130
        canvas.drawCircle(cx, cy, big * 0.82f, paint)

        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#378ADD"); paint.alpha = 35
        canvas.drawCircle(cx, cy, big * 0.62f, paint)
        paint.color = Color.parseColor("#5DCAA5"); paint.alpha = if (fast) 120 else 85
        canvas.drawCircle(cx, cy, big * 0.42f, paint)
        paint.color = Color.parseColor("#9FE1CB"); paint.alpha = 230
        canvas.drawCircle(cx, cy, big * 0.22f, paint)

        for (p in pts) {
            val th = Math.toRadians((p.a + phase * p.s).toDouble())
            val x = cx + (cos(th) * big * 0.9f * p.r).toFloat()
            val y = cy + (sin(th) * big * 0.9f * p.r).toFloat()
            paint.color = p.color
            paint.alpha = 220
            canvas.drawCircle(x, y, 3f, paint)
        }
    }
}
