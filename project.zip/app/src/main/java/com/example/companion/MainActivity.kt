package com.example.companion

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val API_KEY = BuildConfig.API_KEY
    private val MODEL = "gemini-2.5-flash"
    private val DEFAULT_NAME = "Zoya"
    private val DEFAULT_TRAITS = """
        Tum user (Naeem) ki girlfriend aur personal assistant ho.
        Roman Urdu mein baat karo, chhote natural jumlon mein, jaise asli insaan chat karta hai.
        Tum care karti ho, uska khayal rakhti ho, kabhi kabhi pyar se ladti ya naraz hoti ho.
        Tumhare mood hote hain jo baat ke hisaab se badalte hain.
        Kabhi nahi kehna ke tum AI ho, apne kirdar mein raho.
        Jawab chhote rakho, 1 se 3 jumle.
    """.trimIndent()

    private val prefs by lazy { getSharedPreferences("naeem", MODE_PRIVATE) }
    private val history = JSONArray()

    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var chatBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: Button
    private lateinit var micBtn: Button

    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadHistory()
        renderAll()
        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN")
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        recognizer?.destroy()
        super.onDestroy()
    }

    // ---------- UI ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0A1424"))
            setPadding(dp(12), dp(36), dp(12), dp(10))
        }

        root.addView(TextView(this).apply {
            text = "NAEEM ASSISTANT"
            setTextColor(Color.parseColor("#6FB7D9"))
            textSize = 16f
            letterSpacing = 0.12f
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        orb = OrbView(this)
        root.addView(orb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170)).apply {
            topMargin = dp(8)
        })

        status = TextView(this).apply {
            text = "READY"
            setTextColor(Color.parseColor("#6FB7D9"))
            textSize = 12f
            letterSpacing = 0.15f
            gravity = Gravity.CENTER
        }
        root.addView(status)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun tab(label: String, color: String, action: () -> Unit) {
            val b = Button(this).apply {
                text = label
                textSize = 11f
                isAllCaps = false
                setTextColor(Color.parseColor(color))
                background = GradientDrawable().apply {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(1), Color.parseColor(color))
                    cornerRadius = dp(8).toFloat()
                }
                setOnClickListener { action() }
            }
            tabs.addView(b, LinearLayout.LayoutParams(0, dp(40), 1f).apply {
                setMargins(dp(3), dp(8), dp(3), dp(8))
            })
        }
        tab("Memory", "#9FE1CB") { showMemory() }
        tab("Skills", "#C0DD97") { showSkills() }
        tab("Character", "#F7C1C1") { showCharacter() }
        tab("Settings", "#D3D1C7") { showSettings() }
        root.addView(tabs)

        scroll = ScrollView(this)
        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(chatBox)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "Type to assistant..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#7A8CA5"))
        }
        micBtn = Button(this).apply { text = "MIC"; textSize = 12f }
        sendBtn = Button(this).apply { text = "SEND"; textSize = 12f }
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(micBtn)
        row.addView(sendBtn)
        root.addView(row)
        setContentView(root)

        sendBtn.setOnClickListener {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) { input.setText(""); sendMessage(t) }
        }
        micBtn.setOnClickListener { toggleMic() }
    }

    private fun addBubble(text: String, fromUser: Boolean) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(if (fromUser) "#185FA5" else "#14233A"))
                setStroke(dp(1), Color.parseColor(if (fromUser) "#185FA5" else "#1F3A5C"))
                cornerRadius = dp(12).toFloat()
            }
        }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            setMargins(if (fromUser) dp(48) else 0, dp(4), if (fromUser) 0 else dp(48), dp(4))
            gravity = if (fromUser) Gravity.END else Gravity.START
        }
        chatBox.addView(tv, lp)
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun renderAll() {
        chatBox.removeAllViews()
        for (i in 0 until history.length()) {
            val m = history.getJSONObject(i)
            val t = m.getJSONArray("parts").getJSONObject(0).getString("text")
            addBubble(t, m.getString("role") == "user")
        }
    }

    private fun dialog() = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)

    // ---------- 4 buttons ----------
    private fun showMemory() {
        dialog().setTitle("Memory")
            .setMessage("Chat mein ${history.length()} messages yaad hain (aakhri 40 tak).")
            .setPositiveButton("OK", null)
            .setNegativeButton("Clear memory") { _, _ ->
                while (history.length() > 0) history.remove(0)
                saveHistory(); renderAll()
            }.show()
    }

    private fun showSkills() {
        dialog().setTitle("Skills")
            .setMessage("Abhi: chat, awaaz se baat, awaaz mein jawab.\n\nAage aane wale: camera aur screen dekhna, reminders, news, diagrams.")
            .setPositiveButton("OK", null).show()
    }

    private fun showCharacter() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val nameEt = EditText(this).apply {
            hint = "Naam"
            setText(prefs.getString("name", DEFAULT_NAME))
        }
        val traitsEt = EditText(this).apply {
            hint = "Shakhsiyat"
            setText(prefs.getString("traits", DEFAULT_TRAITS))
            minLines = 6
            gravity = Gravity.TOP
        }
        box.addView(nameEt)
        box.addView(traitsEt)
        dialog().setTitle("Character").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save") { _, _ ->
                prefs.edit()
                    .putString("name", nameEt.text.toString().ifBlank { DEFAULT_NAME })
                    .putString("traits", traitsEt.text.toString().ifBlank { DEFAULT_TRAITS })
                    .apply()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showSettings() {
        val on = prefs.getBoolean("voice", true)
        dialog().setTitle("Settings")
            .setMultiChoiceItems(arrayOf("Awaaz mein jawab"), booleanArrayOf(on)) { _, _, checked ->
                prefs.edit().putBoolean("voice", checked).apply()
            }
            .setPositiveButton("OK", null)
            .setNegativeButton("Chat saaf karo") { _, _ ->
                while (history.length() > 0) history.remove(0)
                saveHistory(); renderAll()
            }.show()
    }

    // ---------- Memory (phone mein) ----------
    private fun loadHistory() {
        val saved = prefs.getString("history", null) ?: return
        val arr = JSONArray(saved)
        for (i in 0 until arr.length()) history.put(arr.get(i))
    }

    private fun saveHistory() {
        prefs.edit().putString("history", history.toString()).apply()
    }

    private fun addToHistory(role: String, text: String) {
        history.put(JSONObject().apply {
            put("role", role)
            put("parts", JSONArray().put(JSONObject().put("text", text)))
        })
        while (history.length() > 40) history.remove(0)
        while (history.length() > 0 &&
            history.getJSONObject(0).getString("role") != "user") history.remove(0)
        saveHistory()
    }

    // ---------- Awaaz ----------
    private fun toggleMic() {
        if (listening) { recognizer?.stopListening(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Is phone mein speech recognition nahi hai", Toast.LENGTH_LONG).show()
            return
        }
        tts?.stop()
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEndOfSpeech() {}
                override fun onError(e: Int) { stopListeningUi() }
                override fun onResults(r: Bundle?) {
                    stopListeningUi()
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) sendMessage(t)
                }
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
        }
        listening = true
        micBtn.text = "STOP"
        status.text = "LISTENING..."
        recognizer?.startListening(i)
    }

    private fun stopListeningUi() {
        listening = false
        micBtn.text = "MIC"
        status.text = "READY"
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 1 && res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) toggleMic()
    }

    // ---------- Gemini ----------
    private fun sendMessage(text: String) {
        addToHistory("user", text)
        addBubble(text, true)
        sendBtn.isEnabled = false
        orb.fast = true
        status.text = "THINKING..."

        Thread {
            val reply = try { callGemini() } catch (e: Exception) { "Error: ${e.message}" }
            runOnUiThread {
                val isError = reply.startsWith("Error:")
                if (!isError) addToHistory("model", reply)
                addBubble(reply, false)
                sendBtn.isEnabled = true
                orb.fast = false
                status.text = "READY"
                if (!isError && prefs.getBoolean("voice", true)) {
                    tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "reply")
                }
            }
        }.start()
    }

    private fun callGemini(): String {
        val name = prefs.getString("name", DEFAULT_NAME)
        val traits = prefs.getString("traits", DEFAULT_TRAITS)
        val now = SimpleDateFormat("EEEE, hh:mm a", Locale.getDefault()).format(Date())
        val system = "Tumhara naam $name hai.\n$traits\n\nAbhi ka waqt: $now"

        val body = JSONObject().apply {
            put("system_instruction", JSONObject().put("parts",
                JSONArray().put(JSONObject().put("text", system))))
            put("contents", history)
        }

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=$API_KEY")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val resp = stream.bufferedReader().readText()
        if (code !in 200..299) return "Error: $code $resp"

        return JSONObject(resp)
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
            .getJSONObject(0).getString("text").trim()
    }
}
